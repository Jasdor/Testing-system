package melnik.kursovaya;

public class Configs {
    protected String dbHost = "127.0.0.1";
    protected String dbPort = "3306";
    protected String dbUser = "root";
    protected String dbPassword = "";
    protected String dbName = "kursovaya";
}
