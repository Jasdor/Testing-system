package melnik.kursovaya;

public class Const {
    public static final class LOGIN{
        public static final String LOGIN_TABLE ="login";
        public static final String ID_LOGIN ="idlogin";
        public static final String LOGIN ="login";
        public static final String PASSWORD ="password";
    };

    public static final class USER{
        public static final String USER_TABLE ="user";
        public static final String ID_USER ="id_user";
        public static final String LOGIN_ID ="login_id";
        public static final String FIRST_NAME ="first_name";
        public static final String SECOND_NAME ="second_name";
        public static final String THIRD_NAME ="third_name";
        public static final String ID_UNIVERSITY ="id_university";
        public static final String GENDER_TYPE ="gender_type";
    };

    public static final class USER_TYPE{
        public static final String USER_TYPE_TABLE ="user_type";
        public static final String ID_TYPE ="id_type";
        public static final String NAME ="name";
    };

    public static final class UNIVERSITY {
        public static final String UNIVERSITY_TABLE ="university";
        public static final String ID_UNIVERSITY ="id_university";
        public static final String ID_CITY ="id_city";
        public static final String NAME ="name";
    };

    public static final class CITY{
        public static final String CITY_TABLE ="city";
        public static final String ID_CITY ="id_city";
        public static final String NAME ="name";
    };

    public static final class GROUP{
        public static final String GROUP_TABLE ="group";
        public static final String ID_GROUP ="id_group";
        public static final String NAME ="name";
    };

    public static final class GROUP_SUBJ{
        public static final String GROUP_SUBJ_TABLE ="group_subj";
        public static final String ID_GROUP_SUBJ ="id_group_subj";
        public static final String ID_GROUUP ="id_grouup";
        public static final String ID_SUBJ ="id_subj";
    };

    public static final class SUBJECTS{
        public static final String SUBJECTS_TABLE ="subjects";
        public static final String ID_SUBJ ="id_subj";
        public static final String NAME_SUBJ ="name_subj";
    };

    public static final class THEME{
        public static final String THEME_TABLE ="theme";
        public static final String ID_THEME ="id_theme";
        public static final String NAME ="name";
        public static final String SUBJ_ID ="subj_id";
    };

    public static final class TESTS{
        public static final String TESTS_TABLE ="tests";
        public static final String ID_TEST ="id_test";
        public static final String TEST_NAME ="test_name";
        public static final String QUANTITY_OF_QUEST ="quantity_of_quest";
    };

    public static final class QUESTIONS{
        public static final String QUESTIONS_TABLE ="questions";
        public static final String ID_QUESTION ="id_question";
        public static final String QUEST_TEST_ID ="quest_test_id";
        public static final String QUEST_TEXT ="quest_text";
        public static final String QUESTION_NUMBER ="question_number";
    };

    public static final class ANSWERS{
        public static final String ANSWERS_TABLE ="answers";
        public static final String ID_ANSW ="id_answ";
        public static final String ID_QUESTION ="id_question";
        public static final String RIGHT_ANSWE ="right_answe";
        public static final String ANSW_TEXT ="answ_text";

    };

    public static final class RESULTS{
        public static final String RESULTS_TABLE ="results";
        public static final String ID_RESULT ="id_result";
        public static final String TEST_ID ="test_id";
        public static final String USR_ID ="USR_id";
        public static final String SCORE ="score";
        public static final String DATE ="date";
        public static final String MARK ="mark";
        public static final String DUR ="time";

    };

    public static final class GENDER{
        public static final String GENDER_TABLE ="gender";
        public static final String ID_GENDER ="id_gender";
        public static final String GENDER_NAME ="gender_name";
    };

    public static final class GROUP_MEMB{
        public static final String GROUP_MEMBER_TABLE ="group_member";
        public static final String ID_GROUP_MEMD ="id_group_memd";
        public static final String ID_GROUP ="id_group";
        public static final String ID_USER ="id_user";
        public static final String ID_TYPE ="id_type";
    };
}
