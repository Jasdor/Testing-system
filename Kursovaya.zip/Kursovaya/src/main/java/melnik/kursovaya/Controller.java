package melnik.kursovaya;

import Animations.Shake;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Controller {
    User curuser =new User();

    @FXML
    private Button authbut;

    @FXML
    private TextField loginbox;

    @FXML
    private Button newacc;

    @FXML
    private PasswordField passbox;
    @FXML
    void initialize(){
        authbut.setOnAction(event -> {

            String loginText = loginbox.getText().trim();
            String loginPassword = passbox.getText().trim();
            if (!loginText.equals("") && !loginPassword.equals("")){
                try {
                    loginUser(loginText, loginPassword);
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            else{
                System.out.println("login or password is empty");
            }

        });
        newacc.setOnAction(event ->{
            opennewwind("/melnik/kursovaya/CreateAcc.fxml");

        } );
    }

    private void loginUser(String loginText, String loginPassword) throws SQLException {
        int id=0;
        DataBaseHandler dbHandler = new DataBaseHandler();
        User user =new User();
        user.setUsername(loginText);
        user.setPassword(loginPassword);
        curuser=dbHandler.getUsr_id(user);
        id=curuser.getId_user();
        if (id>=1) {

            opennewwind1("/melnik/kursovaya/Profile.fxml",curuser);
        }
        else {
            Shake userloginAnim = new Shake(loginbox);
            Shake userpassAnim = new Shake(passbox);
            userloginAnim.playAnim();
            userpassAnim.playAnim();
        }

    }

    public Controller() {
    }
    public void opennewwind1(String window,User usinf){
        newacc.getScene().getWindow().hide();
        FXMLLoader loader= new FXMLLoader();
        loader.setLocation(getClass().getResource(window));

        try {
            loader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Parent root =loader.getRoot();
        Profile prof=loader.getController();
        prof.usrinf(usinf);
        Stage stage = new Stage();
        stage.setResizable(false);
        stage.setTitle("Menu");
        stage.setScene(new Scene(root));
        stage.showAndWait();
    }

    public void opennewwind(String window){
        newacc.getScene().getWindow().hide();
        FXMLLoader loader= new FXMLLoader();
        loader.setLocation(getClass().getResource(window));

        try {
            loader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Parent root =loader.getRoot();
        Stage stage = new Stage();
        stage.setResizable(false);
        stage.setTitle("CreateAcc");
        stage.setScene(new Scene(root));
        stage.showAndWait();

    }
}