package melnik.kursovaya;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.lang.String;


import java.io.IOException;

public class CreateAcc {



    @FXML
    private TextField newloginbox;

    @FXML
    private PasswordField newpassbox;

    @FXML
    private PasswordField newpassbox1;

    @FXML
    private ComboBox sexchose;

    @FXML
    private Button CreateUsr;

    @FXML
    private ComboBox citychose;

    @FXML
    private TextField firstname;


    @FXML
    private TextField secondame;

    @FXML
    private TextField thirdname;

    @FXML
    private ComboBox univchose;

    @FXML
    void initialize(){
        //подключение к бд
        DataBaseHandler dbHandler = new DataBaseHandler();
        //заполнение комбобоксов
        ObservableList<String> CityList= FXCollections.observableArrayList( dbHandler.getCity() );
        ObservableList<String> UnivList= FXCollections.observableArrayList(dbHandler.getUniv());
        ObservableList<String> sexchoseList= FXCollections.observableArrayList("Мужской", "Женский");

        //переменные
        sexchose.setItems(sexchoseList);
        univchose.setItems(UnivList);
        citychose.setItems(CityList);

        //функционал кнопки зарегестрироваться
        CreateUsr.setOnAction(actionEvent -> {
            String firstName=firstname.getText();
            String secondName=secondame.getText();
            String thirdName=thirdname.getText();
            String username=newloginbox.getText();
            String password=newpassbox.getText();
            String city=(String)citychose.getValue();
            String gender= (String)sexchose.getValue();
            String university=(String)univchose.getValue();
            User user= new User(firstName, secondName, thirdName, username, password, city, gender, university);
            dbHandler.signUpUser(user);

            CreateUsr.getScene().getWindow().hide();
            FXMLLoader loader= new FXMLLoader();
            loader.setLocation(getClass().getResource("/melnik/kursovaya/hello-view.fxml"));
            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }
            Parent root =loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.showAndWait();
        });
    };

}
