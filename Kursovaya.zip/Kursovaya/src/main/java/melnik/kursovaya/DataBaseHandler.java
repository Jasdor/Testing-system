package melnik.kursovaya;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;
import java.sql.PreparedStatement;
import java.util.ArrayList;

//подключение к бд
public class DataBaseHandler extends Configs {
    User saveusinf=new User();
    Connection dbConnection;
    public Connection getDbConnection()
            throws ClassNotFoundException, SQLException {
        String connectionString ="jdbc:mysql://"+dbHost+":"
                + dbPort +"/" +dbName;

        Class.forName("com.mysql.cj.jdbc.Driver");
        dbConnection = DriverManager.getConnection(connectionString,
                dbUser, dbPassword);
        return dbConnection;
    }


    // получение списка городов для ComBobox
    public ArrayList<String> getCity () {
        String getCities = "SELECT " + Const.CITY.NAME + " FROM " + Const.CITY.CITY_TABLE;
        ArrayList cur=new ArrayList();
        try {
            PreparedStatement gtCty = getDbConnection().prepareStatement(getCities);
           ResultSet rs  = gtCty.executeQuery();
           while(rs.next()) {
               cur.add(rs.getString( Const.CITY.NAME));
           }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return cur;
    }


    // получение списка уч.Учреждений для ComBobox
    public ArrayList<String> getUniv() {
        String getUniv = "SELECT " + Const.UNIVERSITY.NAME + " FROM " + Const.UNIVERSITY.UNIVERSITY_TABLE;
        ArrayList cur=new ArrayList();
        try {
            PreparedStatement gtUniv = getDbConnection().prepareStatement(getUniv);
            ResultSet rs =gtUniv.executeQuery();
            while(rs.next()) {
                cur.add(rs.getString( Const.UNIVERSITY.NAME));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return cur;
    }


    //внесение информации в бд при регистрации пользователя
    public void signUpUser (User user) {
        //добавление информации в таблицу Login
        String insertloginfo = "INSERT INTO " + Const.LOGIN.LOGIN_TABLE + "(" +
                Const.LOGIN.LOGIN + "," + Const.LOGIN.PASSWORD + ")" + " VALUES (?,?)";
        try {
            PreparedStatement prSt = getDbConnection().prepareStatement(insertloginfo);
            prSt.setString(1, user.getUsername());
            prSt.setString(2, user.getPassword());
            prSt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }



        int id=0;
        //получение id пользователя
        String usr_id = "SELECT " + Const.LOGIN.ID_LOGIN + " FROM " + Const.LOGIN.LOGIN_TABLE + " WHERE "
                + Const.LOGIN.LOGIN + "=\"" + user.getUsername() + "\"" + " and " + Const.LOGIN.LOGIN_TABLE +"."+Const.LOGIN.PASSWORD + "= " + "\"" + user.getPassword()+ "\"";
        try {
            PreparedStatement prStlid = getDbConnection().prepareStatement(usr_id);
            ResultSet resultSet = prStlid.executeQuery();
            while (resultSet.next()){
                 id = resultSet.getInt(Const.LOGIN.ID_LOGIN);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }


        int gen_id=0;
        int un_id=0;
        int city_id=0;



        String city_id_get = "SELECT " + Const.CITY.ID_CITY + " FROM " + Const.CITY.CITY_TABLE + " WHERE " +
                Const.CITY.NAME + "=" +"\""+ user.getCity() +"\"";
        try{
            PreparedStatement cty_id_get = getDbConnection().prepareStatement(city_id_get);
            ResultSet rs= cty_id_get.executeQuery();
            while (rs.next()) {
                city_id=rs.getInt(Const.CITY.ID_CITY);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        if (city_id==0) {
            String city_id_set = "INSERT INTO " + Const.CITY.CITY_TABLE + "(" +
                    Const.CITY.NAME + ")" + " VALUES (?)";
            try{
                PreparedStatement cty_id_set =getDbConnection().prepareStatement(city_id_set);
                cty_id_set.setString(1,user.getCity());
                cty_id_set.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }

        }

        try{
            PreparedStatement cty_id_get = getDbConnection().prepareStatement(city_id_get);
            ResultSet rs= cty_id_get.executeQuery();
            while (rs.next()) {
                city_id=rs.getInt(Const.CITY.ID_CITY);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }


        String univ_id = "SELECT " + Const.UNIVERSITY.ID_UNIVERSITY + " FROM " + Const.UNIVERSITY.UNIVERSITY_TABLE + " WHERE " +
                Const.UNIVERSITY.NAME + "=" + "\""+ user.getUniversity() +"\"" + " and "+ Const.UNIVERSITY.ID_CITY + "="+ "\"" +city_id + "\"";
        try {
            PreparedStatement prStlid = getDbConnection().prepareStatement(univ_id);
            ResultSet resultSet = prStlid.executeQuery();
            while (resultSet.next()){
                un_id = resultSet.getInt(Const.UNIVERSITY.ID_UNIVERSITY);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        if (un_id==0){
            String univ_id_set = "INSERT INTO " + Const.UNIVERSITY.UNIVERSITY_TABLE + "(" +
                    Const.UNIVERSITY.ID_CITY + ","+ Const.UNIVERSITY.NAME+ ")" + " VALUES (?,?)";
            try {
                PreparedStatement rs = getDbConnection().prepareStatement(univ_id_set);
                rs.setInt(1,city_id);
                rs.setString(2,user.getUniversity());
                rs.executeUpdate();

            } catch (SQLException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }


        }

        try {
            PreparedStatement prStlid = getDbConnection().prepareStatement(univ_id);
            ResultSet resultSet = prStlid.executeQuery();
            while (resultSet.next()){
                un_id = resultSet.getInt(Const.UNIVERSITY.ID_UNIVERSITY);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }



        String insertusrinfo = "INSERT INTO " + Const.USER.USER_TABLE + "(" +
                Const.USER.LOGIN_ID +"," + Const.USER.FIRST_NAME +","+ Const.USER.SECOND_NAME
                +","+ Const.USER.THIRD_NAME+ "," + Const.USER.ID_UNIVERSITY +"," + Const.USER.GENDER_TYPE+
                ")"+"VALUES (?,?,?,?,?,?)";
        if (user.getGender()=="Мужской")
            gen_id=1;
        else gen_id=2;
        try {
            PreparedStatement prSt = getDbConnection().prepareStatement(insertusrinfo);
            prSt.setInt(1, id);
            prSt.setString(2, user.getFirstName());
            prSt.setString(3, user.getSecondName());
            prSt.setString(4, user.getThirdName());
            prSt.setInt(5,un_id);
            prSt.setInt(6,gen_id);
            prSt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }


    public User getUsr_id(User user) {
        int id=0;
        ResultSet rs=null;
        String usr_id = "SELECT " + Const.LOGIN.ID_LOGIN + " FROM " + Const.LOGIN.LOGIN_TABLE + " WHERE "
                + Const.LOGIN.LOGIN + "=\"" + user.getUsername() + "\"" + " and "
                + Const.LOGIN.LOGIN_TABLE +"."+Const.LOGIN.PASSWORD + "= " + "\"" + user.getPassword()+ "\"";
        try {
            PreparedStatement prStlid = getDbConnection().prepareStatement(usr_id);
            ResultSet resultSet = prStlid.executeQuery();
            while (resultSet.next()){

                id = resultSet.getInt(Const.LOGIN.ID_LOGIN);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        String usr_inf = "SELECT *FROM " + Const.USER.USER_TABLE + " WHERE "
                + Const.USER.LOGIN_ID + "=\"" + id + "\"";
        try {
            PreparedStatement prStinf = getDbConnection().prepareStatement(usr_inf);
            rs = prStinf.executeQuery();

            while(rs.next()){
                user.setFirstName(rs.getString(Const.USER.FIRST_NAME));
                user.setSecondName(rs.getString(Const.USER.SECOND_NAME));
                user.setThirdName(rs.getString(Const.USER.THIRD_NAME));
                user.setUniversity_id(rs.getInt(Const.USER.ID_UNIVERSITY));
                user.setGender_type(rs.getInt(Const.USER.GENDER_TYPE));
                user.setLogin_id(rs.getInt(Const.USER.LOGIN_ID));
                user.setId_user(rs.getInt(Const.USER.ID_USER));

            }
            } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        saveusinf=user;
        return user;
    }



    public ObservableList<Test_result2> testinf(int id){
        int count=0;
        ObservableList<Test_result2> test_results = FXCollections.observableArrayList();
        Test_result testresult= new Test_result();
        String usinf= "SELECT * FROM " +Const.USER.USER_TABLE+" WHERE " + Const.USER.ID_USER +"= \""+id+"\"";
        try {
            PreparedStatement prsu= getDbConnection().prepareStatement(usinf);
            ResultSet rs1=prsu.executeQuery();
            while (rs1.next()){
                testresult.setFirstName(rs1.getString(Const.USER.FIRST_NAME));
                testresult.setSecondName(rs1.getString(Const.USER.SECOND_NAME));
                testresult.setUsr_id(id);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        String testres="SELECT * FROM "+Const.RESULTS.RESULTS_TABLE +
                " WHERE "+ Const.RESULTS.USR_ID + "=" +"\""+ id+ "\"";
        try{
            PreparedStatement prs=getDbConnection().prepareStatement(testres);
            ResultSet rs=prs.executeQuery();
            while (rs.next()){
                count+=1;
                Timestamp datetime = rs.getTimestamp(Const.RESULTS.DATE);

                testresult.setDate(datetime.toString());
                testresult.setScore(rs.getInt(Const.RESULTS.SCORE));

                testresult.setMark(rs.getInt(Const.RESULTS.MARK));
                testresult.setTime(rs.getString(Const.RESULTS.DUR));
                testresult.setTest_id(rs.getInt(Const.RESULTS.TEST_ID));

            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        String testname= "SELECT * FROM "+Const.TESTS.TESTS_TABLE +
                " WHERE "+ Const.TESTS.ID_TEST + "=" +"\"1\"";
        try{
            PreparedStatement testn=getDbConnection().prepareStatement(testname);
            ResultSet rsn = testn.executeQuery();
            while (rsn.next()){
                testresult.setTest_name(rsn.getString(Const.TESTS.TEST_NAME));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        for (int i=0;i<count;i++){
            test_results.add(new Test_result2(i+1,testresult.getTest_name(0),
                    testresult.getDate(i),testresult.getFirstName(),
                    testresult.getSecondName(),testresult.getTime(i),
                    testresult.getScore(i),testresult.getMark(i)));
        }
        return test_results;

    }

    public void getTests(){
        String tests= "SELECT * FROM "+Const.TESTS.TESTS_TABLE;
        try {
            PreparedStatement testsg=getDbConnection().prepareStatement(tests);

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }

    public q_and_a getq(int test_id, int q_num){
        int q_id=0;
        q_and_a q_and_a=new q_and_a();
        String test_q="SELECT * FROM "+Const.QUESTIONS.QUESTIONS_TABLE+
                " WHERE " + Const.QUESTIONS.QUEST_TEST_ID +"=\""+ test_id+ "\""+
                " and "+Const.QUESTIONS.QUESTION_NUMBER + "=\""+q_num +"\"";
        try{
            PreparedStatement testq=getDbConnection().prepareStatement(test_q);
            ResultSet rs= testq.executeQuery();
            while (rs.next()){
                q_and_a.setQuestion(rs.getString(Const.QUESTIONS.QUEST_TEXT));
                q_id=rs.getInt(Const.QUESTIONS.ID_QUESTION);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        String test_a="SELECT * FROM "+Const.ANSWERS.ANSWERS_TABLE+
                " WHERE " + Const.ANSWERS.ID_QUESTION +"=\""+ q_id+ "\"";
        try{
            PreparedStatement testans = getDbConnection().prepareStatement(test_a);
            ResultSet rs = testans.executeQuery();
            while (rs.next()){
                q_and_a.setAnswer(rs.getString(Const.ANSWERS.ANSW_TEXT));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        String test_ra="SELECT * FROM "+Const.ANSWERS.ANSWERS_TABLE+
                " WHERE " + Const.ANSWERS.ID_QUESTION+ " = " +"\""+ q_id+ "\""+
                " and "+Const.ANSWERS.RIGHT_ANSWE + "=\"1\"";
        try{
            PreparedStatement testrans = getDbConnection().prepareStatement(test_ra);
            ResultSet rs = testrans.executeQuery();
            while (rs.next()){

                q_and_a.setR_ans(rs.getString(Const.ANSWERS.ANSW_TEXT));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        return q_and_a;


    }
    public void setresult(int usr_id, int score,Timestamp date,String dur){
        int mark=0;
        String ins_result="INSERT INTO " + Const.RESULTS.RESULTS_TABLE + "(" +
                Const.RESULTS.TEST_ID + "," + Const.RESULTS.USR_ID +
                 "," + Const.RESULTS.SCORE+ "," + Const.RESULTS.DATE +
                 "," + Const.RESULTS.DUR + "," + Const.RESULTS.MARK
                +")" + " VALUES (?,?,?,?,?,?)";
        try{
            PreparedStatement prSt=getDbConnection().prepareStatement(ins_result);
            prSt.setInt(1,1);
            prSt.setInt(2,usr_id);
            prSt.setInt(3,score);
            prSt.setTimestamp(4,date);
            prSt.setString(5,dur);
            float perc=score/13;
            if (perc>0.85)
                mark=5;
            else if (perc>0.75)
                mark=4;
            else if (perc>0.50)
                mark=3;
            else mark=2;

            prSt.setInt(6,mark);
            prSt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }


    }

    public User getUsr_info(int id) {
        User user = new User();
        ResultSet rs=null;
        String usr_inf = "SELECT *FROM " + Const.USER.USER_TABLE + " WHERE "
                + Const.USER.ID_USER + "=\"" + id + "\"";
        try {
            PreparedStatement prStinf = getDbConnection().prepareStatement(usr_inf);
            rs = prStinf.executeQuery();

            while(rs.next()){
                user.setFirstName(rs.getString(Const.USER.FIRST_NAME));
                user.setSecondName(rs.getString(Const.USER.SECOND_NAME));
                user.setThirdName(rs.getString(Const.USER.THIRD_NAME));
                user.setUniversity_id(rs.getInt(Const.USER.ID_UNIVERSITY));
                user.setGender_type(rs.getInt(Const.USER.GENDER_TYPE));
                user.setLogin_id(rs.getInt(Const.USER.LOGIN_ID));
                user.setId_user(rs.getInt(Const.USER.ID_USER));

            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        saveusinf=user;
        return user;
    }


}
