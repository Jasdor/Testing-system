package melnik.kursovaya;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class Profile {

    public void usrinf(User user){
        user_info.setText(user.getFirstName()+" "+ user.getSecondName());
        secret.setText(""+user.getId_user());

    };
    @FXML
    private Button checkres;

    @FXML
    private TextField secret;


    @FXML
    private Button testchose;

    @FXML
    private TextField user_info;


    public void initialize(){

        testchose.setOnAction(event ->{
            int id =showid();
            opennewwindt("/melnik/kursovaya/Tester.fxml",id);

        });
        checkres.setOnAction(event -> {
            int id =showid();
            opennewwindr("/melnik/kursovaya/results.fxml",id);

        });

    }
    public int showid(){
        int id =Integer.parseInt(secret.getText());
        return id;
    }


    public void opennewwindr(String window,int id){
        testchose.getScene().getWindow().hide();
        FXMLLoader loader= new FXMLLoader();
        loader.setLocation(getClass().getResource(window));

        try {
            loader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Parent root =loader.getRoot();
        Results res=loader.getController();
        res.usrinf(id);
        Stage stage = new Stage();
        stage.setResizable(false);
        stage.setTitle("Result");
        stage.setScene(new Scene(root));
        stage.show();

    }
    public void opennewwindt(String window,int id){
        testchose.getScene().getWindow().hide();
        FXMLLoader loader= new FXMLLoader();
        loader.setLocation(getClass().getResource(window));

        try {
            loader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Parent root =loader.getRoot();
        Tester tester=loader.getController();
        tester.getQuestion(1,id,1);
        Stage stage = new Stage();
        stage.setResizable(false);
        stage.setTitle("Test");
        stage.setScene(new Scene(root));
        stage.show();

    }






}
