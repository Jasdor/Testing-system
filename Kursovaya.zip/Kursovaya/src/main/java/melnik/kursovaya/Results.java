package melnik.kursovaya;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;

public class Results {
    User curuser=new User();
    public void usrinf(int id) {
        DataBaseHandler dbHandler =new DataBaseHandler();
        test_results=dbHandler.testinf(id);
        its_user_id.setText(""+id);
        number.setCellValueFactory(new PropertyValueFactory<Test_result2, Integer>("number"));
        test_name.setCellValueFactory(new PropertyValueFactory<Test_result2, String>("test_name"));
        date.setCellValueFactory(new PropertyValueFactory<Test_result2, String>("date"));
        first_name.setCellValueFactory(new PropertyValueFactory<Test_result2, String>("firstName"));
        second_name.setCellValueFactory(new PropertyValueFactory<Test_result2, String>("secondName"));
        time.setCellValueFactory(new PropertyValueFactory<Test_result2, String>("time"));
        right_answ.setCellValueFactory(new PropertyValueFactory<Test_result2, Integer>("score"));
        mark.setCellValueFactory(new PropertyValueFactory<Test_result2, Integer>("mark"));
        tableUsers.setItems(test_results);
    }

    private ObservableList<Test_result2> test_results = FXCollections.observableArrayList();
    @FXML
    private TableColumn<Test_result2, String> date;

    @FXML
    private Button back;


    @FXML
    private TableColumn<Test_result2, String> first_name;

    @FXML
    private TableColumn<Test_result2, Integer> mark;

    @FXML
    private TableColumn<Test_result2, Integer> number;

    @FXML
    private TableColumn<Test_result2, Integer> right_answ;

    @FXML
    private TableColumn<Test_result2, String> second_name;

    @FXML
    private TableView<Test_result2> tableUsers;

    @FXML
    private TableColumn<Test_result2, String> test_name;

    @FXML
    private TableColumn<Test_result2, String> time;
    @FXML
    private TextField its_user_id;

    @FXML
    private void initialize() {
        DataBaseHandler dbHandler = new DataBaseHandler();
        back.setOnAction(event->{
            curuser=dbHandler.getUsr_info(Integer.parseInt(its_user_id.getText()));
            opennewwind1("/melnik/kursovaya/Profile.fxml",curuser);
        });

    }
    public void opennewwind1(String window,User usinf){
        back.getScene().getWindow().hide();
        FXMLLoader loader= new FXMLLoader();
        loader.setLocation(getClass().getResource(window));

        try {
            loader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Parent root =loader.getRoot();
        Profile prof=loader.getController();
        prof.usrinf(usinf);
        Stage stage = new Stage();
        stage.setResizable(false);
        stage.setTitle("Menu");
        stage.setScene(new Scene(root));
        stage.showAndWait();
    }
}

