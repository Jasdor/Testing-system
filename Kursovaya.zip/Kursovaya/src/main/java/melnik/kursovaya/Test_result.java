package melnik.kursovaya;

import java.util.ArrayList;

public class Test_result {

    private ArrayList<Integer> test_id = new ArrayList<Integer>();
    private int usr_id;
    private ArrayList<Integer> score= new ArrayList<Integer>();
    private ArrayList<String> date= new ArrayList<String>();
    private ArrayList<Integer> mark = new ArrayList<Integer>();
    private ArrayList<String> time = new ArrayList<String>();
    private ArrayList<String>  test_name= new ArrayList<String>();
    private String firstName;
    private String secondName;


    public Test_result(){}



    public int getTest_id(int i) {
        return test_id.get(i);
    }

    public void setTest_id(int test_id) {
        this.test_id.add(test_id);
    }

    public String getTest_name(int i) {
        return test_name.get(i);
    }

    public void setTest_name(String test_name) {
        this.test_name.add(test_name);
    }


    public int getUsr_id() {
        return usr_id;
    }

    public void setUsr_id(int usr_id) {
        this.usr_id = usr_id;
    }

    public int getScore(int i) {
        return score.get(i);
    }

    public void setScore(int score) {
        this.score.add(score);
    }

    public String getDate(int i) {
        return date.get(i);
    }

    public void setDate(String date) {
        this.date.add(date);
    }

    public int getMark(int i) {
        return mark.get(i);
    }

    public void setMark(int mark) {
        this.mark.add(mark);
    }

    public String getTime(int i) {
        return time.get(i);
    }

    public void setTime(String time) {
        this.time.add(time);
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getSecondName() {
        return secondName;
    }


    public void setSecondName(String secondName) {
        this.secondName = secondName;
    }
}
