package melnik.kursovaya;

import java.util.ArrayList;

public class Test_result2 {
    private int number;
    private int score;
    private String date;
    private int mark;
    private String time;
    private String test_name;
    private String firstName;
    private String secondName;

    public Test_result2(){

    }

    public Test_result2(int number, String test_name,String date,String firstName, String secondName, String time, int score, int mark) {
        this.number=number;

        this.score = score;
        this.date = date;
        this.mark = mark;
        this.time = time;
        this.test_name = test_name;
        this.firstName = firstName;
        this.secondName = secondName;
    }



    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getMark() {
        return mark;
    }

    public void setMark(int mark) {
        this.mark = mark;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getTest_name() {
        return test_name;
    }

    public void setTest_name(String test_name) {
        this.test_name = test_name;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getSecondName() {
        return secondName;
    }

    public void setSecondName(String secondName) {
        this.secondName = secondName;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }
}



