package melnik.kursovaya;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.sql.Timestamp;

public class Tester {
    int score1 = 0;
    int q_number=1;
    User curuser=new User();
    @FXML
    private ToggleGroup answers;

    @FXML
    private RadioButton answ1;

    @FXML
    private RadioButton answ2;

    @FXML
    private RadioButton answ3;

    @FXML
    private RadioButton answ4;

    @FXML
    private Button nextquest;

    @FXML
    private TextArea questfield;

    @FXML
    private TextField r_answ;

    @FXML
    private TextField test_ID;

    @FXML
    private TextField q_numer;
    @FXML
    private TextField its_user_id;

    public void getQuestion(int test_id,int id,int q_num){
        DataBaseHandler dbHandler = new DataBaseHandler();
        q_and_a q_and_a=new q_and_a();
        q_and_a=dbHandler.getq(test_id,q_num);
        ArrayList<String>  answers= new ArrayList<String>();
        answers= q_and_a.getAnswer();
        q_and_a=dbHandler.getq(test_id,q_num);
        questfield.setText(q_and_a.getQuestion());
        answ1.setText(answers.get(0));
        answ2.setText(answers.get(1));
        answ3.setText(answers.get(2));
        answ4.setText(answers.get(3));
        r_answ.setText(q_and_a.getR_ans());
        test_ID.setText(Integer.toString(test_id));
        q_numer.setText(Integer.toString(q_num));
        its_user_id.setText(Integer.toString(id));


    }
    public void initialize(){
        Timestamp curtime=new Timestamp(System.currentTimeMillis());

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");


        DataBaseHandler dbHandler = new DataBaseHandler();
        nextquest.setOnAction(event -> {
            RadioButton selectButton = (RadioButton) answers.getSelectedToggle();
            if (selectButton != null) {
                String toogleGroupValue = selectButton.getText();
                if (toogleGroupValue.equals(r_answ.getText())){
                    score1+=1;
                }
                q_number=+Integer.parseInt(q_numer.getText());
                q_number+=1;
                if (q_number<14) {
                    getQuestion(Integer.parseInt(test_ID.getText()),Integer.parseInt(its_user_id.getText()), q_number);
                    selectButton.setSelected(false);
                }

                else{
                    Timestamp fintime1 =new Timestamp(System.currentTimeMillis());
                    String dur =Long.toString((fintime1.getTime()-curtime.getTime())/1000);
                    System.out.println((fintime1.getTime()-curtime.getTime())/1000);
                    System.out.println(format.format(fintime1));
                    dbHandler.setresult(Integer.parseInt(its_user_id.getText()),score1,curtime, dur);
                    curuser=dbHandler.getUsr_info(Integer.parseInt(its_user_id.getText()));
                    opennewwind1("/melnik/kursovaya/Profile.fxml",curuser);

                }
            }


        });

    }
    public void opennewwind1(String window,User usinf){
        nextquest.getScene().getWindow().hide();
        FXMLLoader loader= new FXMLLoader();
        loader.setLocation(getClass().getResource(window));

        try {
            loader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Parent root =loader.getRoot();
        Profile prof=loader.getController();
        prof.usrinf(usinf);
        Stage stage = new Stage();
        stage.setResizable(false);
        stage.setTitle("Menu");
        stage.setScene(new Scene(root));
        stage.showAndWait();
    }

}