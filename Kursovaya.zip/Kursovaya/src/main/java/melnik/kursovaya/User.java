package melnik.kursovaya;

public class User {
    private String firstName;
    private String secondName;
    private String thirdName;
    private String username;
    private String password;
    private String city;
    private String gender;
    private String university;
    private int gender_type;
    private int city_id;
    private int university_id;
    private int login_id;
    private int id_user;


    public User() {}

    public User(String firstName, String secondName, String thirdName, String username, String password, String city, String gender, String university) {
        this.firstName = firstName;
        this.secondName = secondName;
        this.thirdName = thirdName;
        this.username = username;
        this.password = password;
        this.city = city;
        this.gender = gender;
        this.university = university;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getSecondName() {
        return secondName;
    }

    public void setSecondName(String secondName) {
        this.secondName = secondName;
    }

    public String getThirdName() {
        return thirdName;
    }

    public void setThirdName(String thirdName) {
        this.thirdName = thirdName;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getUniversity() {
        return university;
    }

    public void setUniversity(String university) {
        this.university = university;
    }

    public int getGender_type() {
        return gender_type;
    }

    public void setGender_type(int gender_type) {
        this.gender_type = gender_type;
    }

    public int getCity_id() {
        return city_id;
    }

    public void setCity_id(int city_id) {
        this.city_id = city_id;
    }

    public int getUniversity_id() {
        return university_id;
    }

    public void setUniversity_id(int university_id) {
        this.university_id = university_id;
    }

    public int getLogin_id() {
        return login_id;
    }

    public void setLogin_id(int login_id) {
        this.login_id = login_id;
    }

    public int getId_user() {
        return id_user;
    }

    public void setId_user(int id_user) {
        this.id_user = id_user;
    }
}
