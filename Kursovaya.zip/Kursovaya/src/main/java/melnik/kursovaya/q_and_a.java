package melnik.kursovaya;

import java.util.ArrayList;

public class q_and_a {
    private String question =new String();
    private ArrayList<String> answer = new ArrayList<String>();
    private String r_ans;
    public q_and_a(){

    }


    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public ArrayList<String> getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer.add(answer);
    }

    public String getR_ans() {
        return r_ans;
    }

    public void setR_ans(String r_ans) {
        this.r_ans = r_ans;
    }
}
